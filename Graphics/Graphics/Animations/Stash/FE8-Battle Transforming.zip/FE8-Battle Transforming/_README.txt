This hack allows manakete-like animations (show idle, transform, fight, transform back). If you're using this as part of a larger project, put the .nmm and .csv files in your Table folder (or wherever csv2ea will convert it) and you should be good to go. If you want to use this on its own, uncomment line 40 in the EA installer file.

Credit to UNKNOWN, with fixes by Aera, for making the japanese version, which was heavily referenced here, and Circleseverywhere for making the nmm.

To insert, assemble "FE8-Battle Transform EA.txt" with EA 10.1 or higher, or #include it in your buildfile.