FE8 Slayer and Effectiveness Rework
By Tequila

Slayer Rework:
Formerly, the Slayer skill was hard-coded to bishops. Now, it reads from an array consisting of 8-byte entries as follows:

[Class ID]	Byte 	The ID of the class with the slayer ability.

[Multipler] Byte 	How much to multiply weapon might by. NOTE: This value is divided by 2 (can be changed in the EA file) so as to allow 1.5x and 2.5x multiplers, etc, but can easily be changed to 4 or 8. Dividing by things that aren't powers of 2 is difficult, so that's not included. 

[Flag]		Byte	If set (ie, non-zero), the function will keep iterating through the table if the enemy class isn't found in this list. This allows you to have 1 class have different multipliers against different classes. For example, Bishop could have 3x effectiveness against monsters and 1.5x against fliers. If the bishop fights a pegasus knight (which isn't in the monster class array), and the flag is set, the game will keep looking for another Bishop entry. The flag must be set for all but the last entry pertaining to that class.	

[Spacer]	Byte	Just here to make the pointer word-aligned. If you can think of a good use for it, let me know.

[Pointer]	Word	A pointer to an array of classes that this class is effective against. As usual, make sure it's written in little endian.

The table is terminated with a 00.

Example: The male bishop's vanilla entry would be as follows: 2B 06 00 00 39 DF 8A 08 

Weapon Effectiveness Rework:
This is an FE8 port of Vennobennu's Effectiveness Rework for FE7, found here: http://feuniverse.us/t/vennos-small-asm-hacks-and-notes/269/9 
It allows for variable effectiveness coefficients for a weapon and different kinds of fili shield-like items. I'm going to paraphrase his readme.txt here.

The effectiveness pointer at byte 0x10 of the item struct now points to a word-aligned array of of 4-byte entries as follows:

[Effectiveness bitfield]	Halfword	A (halfword) bitfield of what class types this weapon is effective against (see below)

[Multiplier]				Byte		How much to multiply the weapon might by. Similar to the Slayer multiplier, it's currently divided by 2 to allow half-integer effectivenesses.

[Spacer]					Byte		Just there to make sure everything's word-aligned.

The table is terminated with a 00.

At byte 0x50 in the class struct, you write a halfword "weakness bitfield" similar to the one mentioned above. It currently says "Unknown Pointer" in Nightmare; Venno says it's safe to use.

The bitfield explained:

Each class "type" is a bit. For instance, let's say armored units are represented by bit 1 (corresponding to a byte value of 0x1) and mounted units are represented by bit 2 (corresponding to a byte value of 0x2). Then armored units would have a "weakness bitfield" of 0x1 and armorslaying weapons would have an effectiveness bitfield of 0x1 as well. Mounted units would have a weakness bitfield of 0x2 and horseslaying weapons would have an effectiveness bitfield of 0x2. For classes that have multiple weaknesses (such as the Great Knight)(or weapons with multiple effectivenesses and identical multipliers), simply sum up each value: 0x1+0x2=0x3.

If you want a weapon to have different multipliers for different class groups (such as Nidhogg having a 2x multipler against monsters, but a 3x multipler against fliers), split up the bitfield as necessary. If fliers are bit 3 (0x4) and monsters are bit 5 (0x10), then Nidhogg's entry would be: 04 00 06 00 10 00 04 00 00.
It could also be written as 10 00 04 00 04 00 06 00 00. The order of entries doesn't matter. If a class is weak to multiple entries in a weapon's array (for instance, Gargoyles are both monsters and fliers), then the highest multiplier will be used.

Protector items:

Items like the Fili Shield, which negate a weapon's effectiveness, are very similar to effective weapons. They use the same effectiveness pointer in addition to setting the 7th bit (0x40) in Weapon Ability 2 (called Negate Flying Weakness in Nightmare). This means that a protector item CANNOT also be an effective item. At the pointer's location, you simply write the class bitfield this item protects against; there's no need for multiple entries because it either fully negates effectiveness or it doesn't. Example: The Fili shield protects fliers, which is bit 3 (0x4). Therefore, at the location pointed to in the effectiveness pointer, simply write 04 00 (remember, little endian).

NOTE: In this hack, I've included a snippet of code that checks if the protector item is actually an item, staff, or ring. If it isn't, the code then checks if the object is equipped. Only if true is the protector effect enabled. To disable this (ie, always apply protective effect), write C0 46 C0 46 at 0x30 in FE8-Weapon Effectiveness Rework.dmp.

Combination: If the attacker has Slayer and an effective weapon, then the higher multipler is used. No more having bishops use Aura instead of Ivaldi!

Class types and which bit value they use:
Armors:			0x1		
Cavalry:		0x2		
Fliers:			0x4		
Wyverns/Dragons	0x8		
Monsters		0x10
Sword users		0x20	(Swordslayer effectiveness)