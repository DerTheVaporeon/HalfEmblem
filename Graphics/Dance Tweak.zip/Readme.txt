If you are installing this by itself (not #included into a greater buildfile), first open up "Dance Tweaks.txt." and follow the instructions next to
the first ORG, located on line 11.

Anyway, assemble this into your FE8 ROM using Event Assembler.

Now dancers can't refresh units who can themselves dance.