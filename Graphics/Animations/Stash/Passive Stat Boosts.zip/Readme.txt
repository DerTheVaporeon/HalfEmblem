	This hack allows items to give stat boosts (except to Constitution and Movement) without having to be equipped. This
behaviour is controlled by setting bit 8 in the Item Ability Byte 3 (labeled 0x80 by the module). If that bit is set,
and the item has a stat boost pointer set, that item will apply its stat bonuses whenever it's in a unit's inventory.

Multiple such items or copies of an item will stack their effects.


Installing with Camtech's Assembly Patcher:
1. "Implementation.dmp" and "script - fe8.txt" are the files you'll need for patching.
Copy them over, along with your FE8 ROM, to wherever you have the assembly patcher installed.
	1a. Replace both occurences of "10 9B 80 08" in Implementation.dmp with a pointer 
	to your item table, if you've repointed it in your ROM.
2. Rename your ROM to fe8.gba (or edit the filename in the script), then drag the script file over "run.py".
3. The program will ask you twice to input an address; enter the address, without the leading 0x8000000, that you
want to place the hack at.
4. You're done! "fe8_patched.gba" is the ROM with the patch applied.


-Vennobennu

