This animation was made with sound effects imported from FE6.
To work correctly, you must import those sound effects or edit the script to use sounds from FE7.
These are the necessary offsets from FE6:
Wind Effect
Table  0x399D18
Header 0x58B438

Hit Effect
Table  0x399D20
Header 0x58B454