	This hack allows items to give stat boosts (except to Constitution and Movement) without having to be equipped.
This behaviour is controlled by setting bit 7 in the Item Ability Byte 3 (that is, 0x80). If that bit is set, and the item
has a stat boost pointer set, that item will apply its stat bonuses whenever it's in a unit's inventory.

	Multiple such items or copies of an item will stack their effects in the ordinary version; alternatively the 'nonstack'
versions will prevent a passively boosting item from providing a boost to a stat that is already boosted by an item higher
up in the unit's inventory.


Installation:
Choose the appropriate Event Assembler file for your game and stackability. Among the first few lines you will see:
#define PassiveBooster 0xB2A610
#define Pas_ItemTable 0x809B10
Or similar. PassiveBooster represents where the new code will be placed in free space; adjust this offset to a 4-aligned
area in free space with about 0x48 bytes free.
Pas_ItemTable refers to the base offset of the item data table. If you've relocated yours you will need to update this
pointer as well.

If you're including this file as part of a larger project, you can define these two in your main buildfile by defining
PASSIVE_BOOST before including it; of course, you'll need to set definitions for the item table offset if it's been moved.
If you're following this method, you could also comment out the "ORG PassiveBooster" line near the bottom of the file,
assuming your main buildfile is already ORG'd to free space.


-Vennobennu