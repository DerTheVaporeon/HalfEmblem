Black Beauty Falcoknight ReadMe

---
Release version 1, 7/25/2011
---

This package has been tested in all situations in a FE7 ROM.
It is possible to replace an existing class, or to expand
the class table.

This package has not been tested in FE8 or FE6 at this time

Palette Sample set is provided.

///

Battle animation by: The Blind Archer (aka Dei Enyt/Dei/TBA)
Animation package by: ShadowofChaos

If you experience any problems, contact either of us via PM
on Serenes Forest, Shrine of Seals, or other community of your
choice.

///